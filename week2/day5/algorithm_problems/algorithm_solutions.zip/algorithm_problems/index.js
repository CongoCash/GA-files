const utilities = require("./utilities");

//Problem 1: Add two numbers together

console.log(utilities.addTwo(2, 3));

console.log(utilities.reverseString("hello"));
